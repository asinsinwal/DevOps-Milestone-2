#!/bin/bash

cd /opt/tomcat9/
./bin/startup.sh