#!/bin/bash

cd /opt/tomcat9/apache-tomcat-9.0.0.M26/
sudo ./bin/startup.sh