#!/bin/bash

cd /home/vagrant/iTrust-v23/iTrust

mvn package
# mvn clean install